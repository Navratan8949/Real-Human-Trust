const mongoose = require("mongoose");

const eventRegistrationSchema = new mongoose.Schema(
    {
        member: {
            type: mongoose.Schema.Types.ObjectId,
            ref: "Member",
            required: true,
        },

        event: {
            type: mongoose.Schema.Types.ObjectId,
            ref: "Event",
            required: true,
        },

        status: {
            type: String,
            enum: ["registered", "approved", "cancelled"],
            default: "registered",
        },

        remarks: {
            type: String,
            default: "",
            trim: true,
        },
    },
    {
        timestamps: true,
    }
);

module.exports = mongoose.model(
    "EventRegistration",
    eventRegistrationSchema
);