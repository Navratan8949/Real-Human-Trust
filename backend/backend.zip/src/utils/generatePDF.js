const pdf = require("pdfkit");
const fs = require("fs");
const path = require("path");

const generateReceiptPDF = (donation, donorName, donorEmail) => {
    return new Promise((resolve, reject) => {
        try {
            const receiptsDir = path.join(__dirname, "..", "..", "receipts");
            if (!fs.existsSync(receiptsDir)) {
                fs.mkdirSync(receiptsDir, { recursive: true });
            }

            const pdfPath = path.join(receiptsDir, `${donation.receiptNumber}.pdf`);
            const doc = new pdf();
            const writeStream = fs.createWriteStream(pdfPath);
            
            doc.pipe(writeStream);
            
            doc.fontSize(20).text("Real Human Trust - Donation Receipt", { align: "center" });
            doc.moveDown();
            doc.fontSize(14).text(`Receipt No: ${donation.receiptNumber}`);
            doc.text(`Date: ${new Date(donation.createdAt).toLocaleDateString()}`);
            doc.text(`Donor Name: ${donorName}`);
            doc.text(`Email: ${donorEmail}`);
            doc.text(`Amount: INR ${donation.amount}`);
            
            if (donation.transactionId) {
                doc.text(`Transaction ID: ${donation.transactionId}`);
            } else {
                doc.text(`Payment ID: ${donation.paymentId}`);
            }
            
            doc.moveDown();
            doc.text("Thank you for your generous contribution!");
            doc.end();

            writeStream.on("finish", () => {
                resolve(pdfPath);
            });

            writeStream.on("error", (err) => {
                reject(err);
            });
        } catch (error) {
            reject(error);
        }
    });
};

module.exports = { generateReceiptPDF };
