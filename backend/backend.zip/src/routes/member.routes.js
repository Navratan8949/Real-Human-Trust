const express = require("express");
const { applyMembership, getAllMembers, approveMember, getMyProfile } = require("../controllers/member.controller");
const isAuthenticated = require("../middleware/auth");
const authorizeRoles = require("../middleware/role");
const upload = require("../utils/multer");

const router = express.Router();

router.post("/apply", isAuthenticated, upload.fields([
    { name: "profileImage", maxCount: 1 },
    { name: "idProof", maxCount: 1 }
]), applyMembership);

router.get("/me", isAuthenticated, getMyProfile);

// Admin / Manager / Coordinator routes
router.get("/", isAuthenticated, authorizeRoles(["super_admin", "admin", "manager", "coordinator"]), getAllMembers);
router.put("/:id/approve", isAuthenticated, authorizeRoles(["super_admin", "admin", "manager"]), approveMember);

module.exports = router;
