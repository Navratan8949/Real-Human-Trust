const express = require("express");
const { createCertificate, getAllCertificates, getMyCertificates } = require("../controllers/certificate.controller");
const isAuthenticated = require("../middleware/auth");
const authorizeRoles = require("../middleware/role");
const upload = require("../utils/multer");

const router = express.Router();

router.get("/me", isAuthenticated, getMyCertificates);

// Admin / Manager routes
router.get("/", isAuthenticated, authorizeRoles(["super_admin", "admin", "manager"]), getAllCertificates);
router.post("/", isAuthenticated, authorizeRoles(["super_admin", "admin", "manager"]), upload.single("pdf"), createCertificate);

module.exports = router;
