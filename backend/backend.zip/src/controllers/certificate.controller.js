const Certificate = require("../models/Certificate");
const Member = require("../models/Member");
const { uploadOnCloudinary } = require("../utils/cloudinary");

exports.createCertificate = async (req, res) => {
    try {
        const { memberId, certificateNo, title, description, status } = req.body;
        let pdf = { public_id: "", url: "" };
        if (req.file) {
            const uploadResult = await uploadOnCloudinary(req.file.path);
            if (uploadResult) {
                pdf = { public_id: uploadResult.public_id, url: uploadResult.url };
            }
        }

        const member = await Member.findById(memberId);
        if (!member) {
            return res.status(404).json({ success: false, message: "Member not found" });
        }

        const certificate = await Certificate.create({
            member: memberId,
            certificateNo,
            title,
            description,
            status,
            pdf
        });

        member.certificate.push(certificate._id);
        await member.save();

        res.status(201).json({ success: true, certificate });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
};

exports.getAllCertificates = async (req, res) => {
    try {
        const certificates = await Certificate.find().populate({
            path: "member",
            populate: { path: "user", select: "fullName email" }
        }).sort("-issueDate");
        res.status(200).json({ success: true, count: certificates.length, certificates });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
};

exports.getMyCertificates = async (req, res) => {
    try {
        const member = await Member.findOne({ user: req.user.id });
        if (!member) {
            return res.status(404).json({ success: false, message: "Member not found" });
        }

        const certificates = await Certificate.find({ member: member._id }).sort("-issueDate");
        res.status(200).json({ success: true, count: certificates.length, certificates });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
};
