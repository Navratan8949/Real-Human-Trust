const Member = require("../models/Member");
const Donation = require("../models/Donation");
const Project = require("../models/Project");
const Event = require("../models/Event");
const Complaint = require("../models/Complaint");
const Crowdfunding = require("../models/Crowdfunding");
const Volunteer = require("../models/Volunteer");

exports.getDashboardStats = async (req, res) => {
    try {
        // --- 1. Basic Counts ---
        const totalMembers = await Member.countDocuments();
        const approvedMembers = await Member.countDocuments({ membershipStatus: "approved" });

        const totalProjects = await Project.countDocuments();
        const activeProjects = await Project.countDocuments({ status: "active" });

        const totalEvents = await Event.countDocuments();
        const upcomingEvents = await Event.countDocuments({ status: "upcoming" });

        const donations = await Donation.find({ paymentStatus: { $in: ["success", "verified"] } });
        const totalDonationAmount = donations.reduce((sum, d) => sum + d.amount, 0);
        const totalDonationCount = donations.length;

        // --- 2. Actionable Alerts (Pending Items for Admin) ---
        const pendingMembersList = await Member.find({ membershipStatus: "pending" })
            .populate("user", "fullName email")
            .sort("-createdAt")
            .limit(5);
        const pendingMembersCount = await Member.countDocuments({ membershipStatus: "pending" });

        const pendingDonationsList = await Donation.find({ paymentStatus: "pending", paymentId: "manual" })
            .populate({ path: "member", populate: { path: "user", select: "fullName" } })
            .sort("-createdAt")
            .limit(5);
        const pendingDonationsCount = await Donation.countDocuments({ paymentStatus: "pending", paymentId: "manual" });

        const openComplaintsList = await Complaint.find({ status: "pending" })
            .populate({ path: "member", populate: { path: "user", select: "fullName" } })
            .sort("-createdAt")
            .limit(5);
        const openComplaintsCount = await Complaint.countDocuments({ status: "pending" });

        const pendingVolunteersList = await Volunteer.find({ status: "pending" }).sort("-createdAt").limit(5);
        const pendingVolunteersCount = await Volunteer.countDocuments({ status: "pending" });

        // --- 3. Crowdfunding Progress ---
        const activeCrowdfundings = await Crowdfunding.find({ status: "active" }).select("title targetAmount raisedAmount endDate");
        
        // --- 4. Monthly Donation Trends (Last 6 Months) ---
        const sixMonthsAgo = new Date();
        sixMonthsAgo.setMonth(sixMonthsAgo.getMonth() - 5);
        sixMonthsAgo.setDate(1);

        const recentDonations = await Donation.find({
            paymentStatus: { $in: ["success", "verified"] },
            createdAt: { $gte: sixMonthsAgo }
        });

        // Group by month
        const monthlyDonationsMap = {};
        recentDonations.forEach(d => {
            const monthYear = `${d.createdAt.toLocaleString('default', { month: 'short' })} ${d.createdAt.getFullYear()}`;
            if (!monthlyDonationsMap[monthYear]) {
                monthlyDonationsMap[monthYear] = 0;
            }
            monthlyDonationsMap[monthYear] += d.amount;
        });

        const monthlyTrends = Object.keys(monthlyDonationsMap).map(key => ({
            month: key,
            amount: monthlyDonationsMap[key]
        }));

        res.status(200).json({
            success: true,
            stats: {
                overview: {
                    members: { total: totalMembers, approved: approvedMembers },
                    projects: { total: totalProjects, active: activeProjects },
                    events: { total: totalEvents, upcoming: upcomingEvents },
                    donations: { totalAmount: totalDonationAmount, count: totalDonationCount }
                },
                actionableAlerts: {
                    pendingMembers: { count: pendingMembersCount, list: pendingMembersList },
                    pendingDonations: { count: pendingDonationsCount, list: pendingDonationsList },
                    openComplaints: { count: openComplaintsCount, list: openComplaintsList },
                    pendingVolunteers: { count: pendingVolunteersCount, list: pendingVolunteersList }
                },
                crowdfunding: activeCrowdfundings,
                monthlyTrends: monthlyTrends
            }
        });

    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
};
