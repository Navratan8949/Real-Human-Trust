const Member = require("../models/Member");
const User = require("../models/User");
const QRCode = require("qrcode");
const { uploadOnCloudinary } = require("../utils/cloudinary");

const generateMemberId = () => {
    return "RHTM" + Math.floor(100000 + Math.random() * 900000);
};

exports.applyMembership = async (req, res) => {
    try {
        const {
            bloodGroup, occupation, membershipType, referredBy
        } = req.body;

        const userId = req.user.id;

        const existingMember = await Member.findOne({ user: userId });
        if (existingMember) {
            return res.status(400).json({ success: false, message: "Membership already applied." });
        }

        const memberId = generateMemberId();

        // Handle profileImage upload (for ID card — can differ from login profile pic)
        let profileImage = { public_id: "", url: "" };
        const profileFile = req.files && req.files["profileImage"] ? req.files["profileImage"][0] : null;
        if (profileFile) {
            const uploadResult = await uploadOnCloudinary(profileFile.path);
            if (uploadResult) {
                profileImage = { public_id: uploadResult.public_id, url: uploadResult.url };
            }
        }

        // Handle idProof upload (Aadhar / PAN / Voter ID)
        let idProof = { public_id: "", url: "" };
        const idProofFile = req.files && req.files["idProof"] ? req.files["idProof"][0] : null;
        if (idProofFile) {
            const uploadResult = await uploadOnCloudinary(idProofFile.path);
            if (uploadResult) {
                idProof = { public_id: uploadResult.public_id, url: uploadResult.url };
            }
        }

        const member = await Member.create({
            user: userId,
            memberId,
            bloodGroup: bloodGroup || "",
            occupation: occupation || "",
            membershipType: membershipType || "general",
            referredBy: referredBy || null,
            profileImage,
            idProof,
            membershipStatus: "pending",
        });

        res.status(201).json({ success: true, message: "Membership application submitted successfully.", member });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
};


exports.getAllMembers = async (req, res) => {
    try {
        const members = await Member.find().populate("user", "fullName email mobile role").sort("-createdAt");
        res.status(200).json({ success: true, count: members.length, members });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
};

exports.approveMember = async (req, res) => {
    try {
        const member = await Member.findById(req.params.id);
        if (!member) {
            return res.status(404).json({ success: false, message: "Member not found" });
        }

        member.membershipStatus = "approved";

        // Generate QR Code containing member verification link (e.g., to a frontend profile page)
        const verificationLink = `${process.env.FRONTEND_URL || "http://localhost:3000"}/verify-member/${member.memberId}`;
        const qrCodeData = await QRCode.toDataURL(verificationLink);
        
        member.qrCode = qrCodeData;

        await member.save();

        res.status(200).json({ success: true, message: "Member approved and QR Code generated", member });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
};

exports.getMyProfile = async (req, res) => {
    try {
        const member = await Member.findOne({ user: req.user.id }).populate("user", "fullName email mobile");
        if (!member) {
            return res.status(404).json({ success: false, message: "Membership details not found" });
        }
        res.status(200).json({ success: true, member });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
};
